#! /bin/bash
# R3nt0n (https://www.github.com/R3nt0n)

sudo apt-get install python
sudo apt-get install tor
pip install requirements.txt
